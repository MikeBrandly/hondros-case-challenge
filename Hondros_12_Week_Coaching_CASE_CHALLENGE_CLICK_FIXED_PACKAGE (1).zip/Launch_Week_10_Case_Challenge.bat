@echo off
cd /d "%~dp0"
start "" "Week_10_Ohio_Real_Estate_Case_Challenge.html"
exit
