@echo off
cd /d "%~dp0"
start "" "Week_12_Ohio_Real_Estate_Case_Challenge.html"
exit
