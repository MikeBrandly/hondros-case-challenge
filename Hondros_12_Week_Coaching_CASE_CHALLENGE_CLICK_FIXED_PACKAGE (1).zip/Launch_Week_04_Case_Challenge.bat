@echo off
cd /d "%~dp0"
start "" "Week_04_Ohio_Real_Estate_Case_Challenge.html"
exit
