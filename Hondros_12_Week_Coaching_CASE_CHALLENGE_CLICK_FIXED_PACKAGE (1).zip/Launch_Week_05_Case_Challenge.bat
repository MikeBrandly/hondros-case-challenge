@echo off
cd /d "%~dp0"
start "" "Week_05_Ohio_Real_Estate_Case_Challenge.html"
exit
